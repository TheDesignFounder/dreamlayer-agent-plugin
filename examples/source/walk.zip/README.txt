DreamLayer sprite sheet
Action: walk
7 frames, row-major order, 128 x 128 cells, 3 columns.
Duration: 2833 ms. Sampling: cycle. A sequence is not guaranteed to loop. Shared scale; alignment: ground_anchor. Enlarged: False; enlargement adds no source detail.
Unity: slice the sheet into 128 x 128 cells.
Godot: create SpriteFrames using a 3 x 3 grid; use only the 7 atlas entries.
Phaser: load sheet.png and atlas.json with load.atlas.
